МАТ-БУМ! 3 «Побег из сферы» — Yandex Games build 0.5.0
=====================================================
Архив для загрузки в консоль Яндекс Игр.

Состав (корень архива = корень игры):
  index.html
  js/platform.js
  assets/figures/01.jpg … 10.jpg

SDK: /sdk.js отдаёт платформа (в архив НЕ кладётся).
platform.js подключает SDK, LoadingAPI.ready, GameplayAPI,
облако, лидерборд, rewarded — с деградацией в гостя.

Требования: https://yandex.ru/dev/games/doc/ru/concepts/requirements
В UI игроку НЕ показывается «яндекс» / «яндекс игры».

Перед заливом: проверьте RU/EN, музей, финал фигурки, АВТО/рекламу.
