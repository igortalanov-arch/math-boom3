MB3 yandex 0.5.2
