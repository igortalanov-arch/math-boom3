MB3 solo 0.5.2
